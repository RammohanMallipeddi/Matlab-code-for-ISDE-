function obj = feed_constraint_dairy(X) 

weight = 500; %in Kg

load Data.mat;

[N D] = size(X);  % population=1: 68,dimensions =14

obj1 = sum(X.*repmat(Data(1,:),N,1),2); 

obj2 = sum(X,2);
for i =1:size(X,1)
obj3(i,:) = length(find(X(i,:)>=10^(-4)));
end

cons1   =  abs(sum(X.*repmat(Data(12,:),N,1),2)-25.67);

cons2   =  abs(sum(X.*repmat(Data(2,:),N,1),2)-0.02);

cons3   =  abs(sum(X.*repmat(Data(3,:),N,1),2)-0.062);

cons4   =  abs(sum(X.*repmat(Data(13,:),N,1),2)-0.031);

cons5   =  abs(sum(X.*repmat(Data(14,:),N,1),2)-0.021);

cons6   =  abs(sum(repmat(sum(Data(2:11,:),1),N,1).*X,2)-0.999);

%obj2 = sum([cons1,cons2,cons3,cons4,cons5,cons6],2); 

obj = [obj1 obj2 obj3 cons1 cons2 cons3 cons4 cons5 cons6];
