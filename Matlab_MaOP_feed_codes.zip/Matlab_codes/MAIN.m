% Matlab code:paper: ISDE+ An indicator for Multi and Many objective optimization
% Authors: Rammohan Mallipeddi; Trinadh Pamulapati; P.N. Suganthan

% Email: trinadhpamulapati@gmail.com; mallipeddi.ram@gmail.com; epnsugan@ntu.edu.sg

clc;format compact;tic;

%-----------------------------------------------------------------------------------------
% Problem Selection and Problem Paramaters
       
        
        D = 64;
        M = 9;
        
        MinValue   = zeros(1,D);
        MaxValue   = 10*ones(1,D);
        
        
        %-----------------------------------------------------------------------------------------
        % Algorithm parameters
          
        Generations = 5000;	 % number of iterations
            
        N = 300;
            
        
        
        Runs = 1;
        
        Boundary = [MaxValue;MinValue];
        %-----------------------------------------------------------------------------------------
        for run = 1: Runs
            
            % initialize the population
            Population                    = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue                 = feed_constraint_dairy(Population);     % calculate the objective function values
            DistanceValue                 = F_distance(FunctionValue,M);
            %-----------------------------------------------------------------------------------------
            % start iterations
            for Gene = 1 : Generations
                                
                MatingPool       = MatingSelection(FunctionValue,DistanceValue,M);
                NewPopulation    = F_operator(Population(MatingPool',:),Boundary); %offspring production
                
                Population       = [Population;NewPopulation];                     % combine the two populations
                FunctionValue    = feed_constraint_dairy(Population);                 % calculate the objective function values
                
                DistanceValue    = F_distance(FunctionValue,M);                   
                
                [~,rank]         = sort(DistanceValue,'ascend');                  
                % next population
                Population       = Population(rank(1:N),:);         	
                FunctionValue    = FunctionValue(rank(1:N),:);
                DistanceValue    = DistanceValue(rank(1:N));
                %Gene
            end
            
            F_output(Population);
            
        end
        
        
        
 